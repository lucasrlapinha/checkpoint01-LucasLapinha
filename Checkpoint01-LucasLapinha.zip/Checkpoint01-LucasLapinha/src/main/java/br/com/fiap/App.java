package br.com.fiap;

import br.com.fiap.entity.Livro;

public class App {

    public static void main(String[] args) {

        LivroServiceImpl livroService = LivroServiceImpl.getInstance();

        livroService.inserir(new Livro(
                "Livro 1",
                "Lucas",
                "275-0-9054-6707-2",
                2)
        );
        livroService.inserir(new Livro(
                "Livro 2",
                "Lapinha",
                "778-0-6534-3008-2",
                1)
        );
        livroService.inserir(new Livro(
                "Livro 3",
                "Douglas Adams",
                "123-0-5784-2909-2",
                1)
        );

        livroService.listar();

        livroService.remover(3L);

        livroService.atualizar((new Livro(
                "Dias que a internet da FIAP não funcionou",
                "Lapinha",
                "778-0-6534-3008-2",
                3)
        ));

    }
}
